# مشروع تطبيق السجل المدني Android

هذا مشروع تجهيز لتحويل اللعبة إلى تطبيق Android باستخدام Capacitor.
ملفات اللعبة موجودة داخل www/، مع إعداد اسم التطبيق ومعرّفه وأيقونة مبدئية.

## المتطلبات
- كمبيوتر Windows أو macOS أو Linux
- Node.js LTS
- Android Studio مع Android SDK
- اتصال إنترنت عند تثبيت حزم Capacitor أول مرة

## إنشاء مشروع Android
افتح Terminal داخل هذا المجلد ونفّذ:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

داخل Android Studio:
1. انتظر انتهاء Gradle Sync.
2. من Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
3. بعد نجاح البناء ستجد APK داخل:
   `android/app/build/outputs/apk/debug/app-debug.apk`

## تحديث اللعبة لاحقًا
بعد تعديل `www/index.html` نفّذ:
```bash
npx cap sync android
```
ثم أعد بناء APK من Android Studio.

## ملاحظات
- هذا مشروع مصدر وتجهيز للبناء، وليس APK مبنيًا بالفعل.
- اسم الحزمة: com.ayman.civilregistry
- اسم التطبيق: السجل المدني
- اللعبة تجريبية وخيالية؛ لا تمثل جهة حكومية ولا تصدر وثائق رسمية.
